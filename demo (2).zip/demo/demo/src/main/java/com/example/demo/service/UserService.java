package com.ecocredits.backend.service;

import com.ecocredits.backend.model.User;
import com.ecocredits.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(String username) {
        User user = new User();
        user.setUsername(username);
        return userRepository.save(user);
    }

    public User addPoints(String username, int points) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            user.setPoints(user.getPoints() + points);
            return userRepository.save(user);
        }
        return null;
    }

    public User redeemReward(String username, int points) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPoints() >= points) {
            user.setPoints(user.getPoints() - points);
            return userRepository.save(user);
        }
        return null;
    }
}package com.ecocredits.backend.service;

        import com.ecocredits.backend.model.User;
        import com.ecocredits.backend.repository.UserRepository;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(String username) {
        User user = new User();
        user.setUsername(username);
        return userRepository.save(user);
    }

    public User addPoints(String username, int points) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            user.setPoints(user.getPoints() + points);
            return userRepository.save(user);
        }
        return null;
    }

    public User redeemReward(String username, int points) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPoints() >= points) {
            user.setPoints(user.getPoints() - points);
            return userRepository.save(user);
        }
        return null;
    }
}