package com.ecocredits.backend.controller;

import com.ecocredits.backend.model.User;
import com.ecocredits.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestParam String username) {
        User user = userService.registerUser(username);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/earn-points")
    public ResponseEntity<User> earnPoints(@RequestParam String username, @RequestParam int points) {
        User user = userService.addPoints(username, points);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @PostMapping("/redeem-reward")
    public ResponseEntity<User> redeemReward(@RequestParam String username, @RequestParam int points) {
        User user = userService.redeemReward(username, points);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }
}