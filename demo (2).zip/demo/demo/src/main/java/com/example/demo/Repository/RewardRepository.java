package com.ecocredits.backend.repository;

import com.ecocredits.backend.model.Reward;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RewardRepository extends JpaRepository<Reward, Long> {
}