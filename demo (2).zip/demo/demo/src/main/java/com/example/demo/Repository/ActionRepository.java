package com.ecocredits.backend.repository;

import com.ecocredits.backend.model.Action;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActionRepository extends JpaRepository<Action, Long> {
}